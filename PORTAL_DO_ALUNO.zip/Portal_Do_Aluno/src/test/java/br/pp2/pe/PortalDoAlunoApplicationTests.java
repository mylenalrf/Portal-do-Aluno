package br.pp2.pe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalDoAlunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
